



// ADAPTMATCH.h
#ifndef _ADAPTMATCH_H_
#define _ADAPTMATCH_H_    //#endif  // _ADAPTMATCH_H_ //

// �ṹ���� ADAPTMATCH.CPP ��ʵ��
#ifdef  _ADAPTMATCH_CPP_    //#endif  // _ADAPTMATCH_CPP_ //
#define ADAPTMATCH_EXTERN 
#else 
#define ADAPTMATCH_EXTERN extern 
#endif  // _ADAPTMATCH_CPP_ //



#include "tesseract/ccutil/host.h"

#include "tesseract/ccutil/unichar.h"
#include "tesseract/classify/shapetable.h"




#define WORST_POSSIBLE_RATING (0.0f)

using tesseract::UnicharRating;


struct ADAPT_RESULTS {
  inT32 BlobLength;
  bool HasNonfragment;
  UNICHAR_ID best_unichar_id;
  int best_match_index;
  FLOAT32 best_rating;
  GenericVector<UnicharRating> match;
  GenericVector<CP_RESULT_STRUCT> CPResults;

  /// Initializes data members to the default values. Sets the initial
  /// rating of each class to be the worst possible rating (1.0).
  inline void Initialize() {
    BlobLength = MAX_INT32;
    HasNonfragment = false;


   assert(match.size()==0);  // qTrace(" match.size()=%d", match.size());

    ComputeBest();

  }



  // Computes best_unichar_id, best_match_index and best_rating.
  void ComputeBest() {
    best_unichar_id = INVALID_UNICHAR_ID;
    best_match_index = -1;
    best_rating = WORST_POSSIBLE_RATING;



    for (int i = 0; i < match.size(); ++i) {
      if (match[i].rating > best_rating) {
        best_rating = match[i].rating;
        best_unichar_id = match[i].unichar_id;
        best_match_index = i;
      }
    }
  }
};







#endif  // _ADAPTMATCH_H_ //
