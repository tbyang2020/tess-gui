

// ALGORITHM.h
#ifndef _ALGORITHM_H_
#define _ALGORITHM_H_    //#endif  // _ALGORITHM_H_ //

// �ṹ���� ALGORITHM.CPP ��ʵ��
#ifdef  _ALGORITHM_CPP_    //#endif  // _ALGORITHM_CPP_ //
#define ALGORITHM_EXTERN 
#else 
#define ALGORITHM_EXTERN extern 
#endif  // _ALGORITHM_CPP_ //









void On_IDT_TEST();  





#endif  // _ALGORITHM_H_ //


