



#ifndef _MAIN_H_

#define _MAIN_H_


int main32(char*pic, char*outputbase=0, char*lang="eng");


#endif  //  _MAIN_H_ 