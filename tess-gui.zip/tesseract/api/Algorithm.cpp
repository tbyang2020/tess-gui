


#define     _ALGORITHM_CPP_   


#include  "Algorithm.h"

#include <Windows.h> 
#include <stdio.h> 


#include "InterfaceMDI/qTrace.h"
#include "InterfaceMDI/InterfaceMDI.h"  // bool GetFileName(LPTSTR szFile, bool bSave = FALSE, LPCTSTR pFilter = 0L, HWND hWnd = 0L);    // InterfaceMDI.cpp 


#include "tessdatamanager.h"
using namespace tesseract;



// namespace tesseract {







#if  TEMPLATE_DATAS |1   // InitAdaptiveClassifier, adaptmatch.cpp Ln527;   tessedit.cp;   char_set.cpp; dict.cpp;  dawg_cache.cpp;  tess_lang_model.cpp 

// tessdatamanager.cpp   SeekToStart, GetEndOffset ��ȡ����Ŀ�ʼ������   

// TESSDATA_LANG_CONFIG   = 0   // tessedit.cpp Ln 165  // If a language specific config file (lang.config) exists, load it in.
int ReadParamsFromFp(FILE* fp){ return 0; }



// TESSDATA_UNICHARSET = 1    //   LoadSupportedCharList   char_set.cpp Ln 80
int Load_UniCharset(FILE* fp){ return 0; }



// TESSDATA_AMBIGS = 2   // LoadUnicharAmbigs  tessedit.cpp  Ln 284 

int Load_UniCharAnbigs(FILE* fp){ return 0; }


// TESSDATA_INTTEMP = 3    // pruner ��֦���޼�
int ReadIntTemplates(FILE* fp){ return 0; }



// TESSDATA_PFFMTABLE = 4  
int ReadPfFmtTable(FILE* fp) { return 0; }


// TESSDATA_NORMPROTO  = 5  
int ReadNormProtos(FILE* fp) { return 0; }



// TESSDATA_PUNC_DAWG  = 6    // dawg_cache.cpp  Ln 70 
int LoadDawg(FILE* fp) { return 0; }


// TESSDATA_SYSTEM_DAWG  = 7    // dawg_cache.cpp  Ln 70 
// TESSDATA_NUMBER_DAWG,         // 8
// TESSDATA_FREQ_DAWG,           // 9
// TESSDATA_FIXED_LENGTH_DAWGS,  // 10  // deprecated

// TESSDATA_CUBE_UNICHARSET = 11 //   load_from_file    char_set.cpp Ln 79
int Load_Cube_UniCharset(FILE* fp) { return 0; }


// TESSDATA_CUBE_SYSTEM_DAWG,    // 12

//  SquishedDawg   tess_lang_model.cpp  



// TESSDATA_SHAPE_TABLE = 13 
int ReadShapeTable(FILE* fp) { return 0; }


// TESSDATA_BIGRAM_DAWG,         // 14
// TESSDATA_UNAMBIG_DAWG,        // 15

// TESSDATA_PARAMS_MODEL,        // 16    // getParamsModel  tessedit.cpp Ln 328 


// TESSDATA_NUM_ENTRIES = 17  

#endif   // TEMPLATE_DATAS








#if FROM_TESSDATAMANAGER |1



inline
inT64 GetEndOffset(const int tessdata_type, const int actual_tessdata_num_entries_, const  INT64*offset_table_)  {
    
    if (offset_table_[tessdata_type] == -1) return -1;  //  ע--�����ڵ�������βҲ������  

    int index = tessdata_type + 1;
    while (index < actual_tessdata_num_entries_ && offset_table_[index] == -1) {
        ++index;  // skip tessdata types not present in the combined file
    }

return (index == actual_tessdata_num_entries_) ? -1 : offset_table_[index] - 1;
}






#endif  // FROM_TESSDATAMANAGER









// tr_read, ��ȡ .traineddata �ļ�  

// �ο����� 

// TessdataManager::Init,  tessdatamanager.cpp   




int tr_read(const char*sfn, const char*dfn){

FILE* data_file_ = fopen(sfn, "rb");

if (data_file_ == NULL) {
qTrace( "%s\r\nERR %X\r\n%s", sfn, errno, strerror(errno) ) ;
return false;
}


if(!dfn) dfn="tr_read.log"; 

FILE*fd=fopen(dfn,"wb");  

fseek(data_file_, 0, SEEK_END);
size_t size = ftell(data_file_);
fseek(data_file_, 0, SEEK_SET);


fprintf(fd,"[file_size] %d     \r\n",  size);





int num_entries=0; 
fread(&num_entries, sizeof(int), 1, data_file_);



fprintf(fd,"[num_entries] %d  -- ", num_entries);  


bool  swap = (num_entries > 1000);  // kMaxNumTessdataEntries = 1000 


if (swap ) {

qTrace("num_entries=%d\r\n�ֽڴ洢ѭ��Ϊ big-endian, ��Ҫת��Ϊ little-endian.", num_entries);
        // ReverseN(&num_entries_, sizeof(num_entries_));  // ����, in big-endian, 'ihdr' �洢Ϊ 69 68 64 72.  �� in little-endian,   'ihdr' �洢Ϊ 72 64 68 69.
        // So if the bytes come in sequence from left to right, we tore them on little - endians in byte order :
        // 3 2 1 0 7 6 5 4 ...

}  // if (num_entries > 1000) 


fprintf(fd,"%d \r\n[swap] %d\r\n", num_entries, swap);  



if (num_entries >17) {  // 17 =  TESSDATA_NUM_ENTRIES
// num_entries = 17;  // For forward compatibility, truncate to the number we can handle.
}  // if (num_entries >17) 



INT64* offset_table = new INT64 [num_entries];

fread(offset_table, sizeof(INT64), num_entries, data_file_);



INT64 ie;  


for (int i = 0; i < num_entries; i++) {

     
 
    ie =  GetEndOffset(i, num_entries, offset_table);
    //qTrace("ie=%lld",ie);



if(ie==-1 && offset_table[i]>0 )  ie=size; 

fprintf(fd, "[offset_table %d] %lld -- %lld\r\n", i, offset_table[i], ie);

}  // for -- offset_table



if (swap) {
for ( int i = 0; i <  num_entries; ++i) {

// ReverseN(&offset_table_[i], sizeof(offset_table_[i]));
fprintf(fd, "[offset_table %d] %lld\r\n", i, offset_table[i]);

}  // for -- swap 
}  // if (swap) 



fclose(data_file_);
fclose(fd);



ShellExecute(0, "open", dfn, 0, 0, SW_SHOW);       

delete[] offset_table;
return num_entries;
}






//}    // namespace tesseract  





// WndProc IDT_TEST, һ�����-��ʱ���� 

void On_IDT_TEST(){

char szFile[256] = { 0 };
    bool bok = GetFileName(szFile);
    if (!bok) return;

    tr_read(szFile,0L);

}





