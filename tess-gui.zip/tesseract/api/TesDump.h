

// TESDUMP.h
#ifndef _TESDUMP_H_
#define _TESDUMP_H_      //#endif  // _TESDUMP_H_ //

// �ṹ���� TESDUMP.CPP ��ʵ��
#ifdef  _TESDUMP_CPP_    // #define  _TESDUMP_CPP_ //
#define TESDUMP_EXTERN 
#else 
#define TESDUMP_EXTERN extern 
#endif  // _TESDUMP_CPP_ //







#include <Windows.h>
#include <shellapi.h>




#include "tesseract/ccstruct/pageres.h"
 



#include "tesseract/classify/adaptmatch.h"


#include "tesseract/classify/trainingsample.h"

#include "tesseract/classify/tessclassifier.h"

#include "tesseract/classify/trainingsample.h"

using namespace tesseract;  




int get_bbs(BLOCK*block);  // blobs count in a block  
int get_bbs(BLOCK_LIST *blocks); 



int get_size(PAGE_RES* page_res); 
int get_size(WERD*src); 


const char* get_str(GenericVector<UnicharRating> unichar_results, const UNICHARSET* unicharset=0); 
const char* get_str(ADAPT_RESULTS *Results, const UNICHARSET* unicharset=0);  
const char* get_str(BLOB_CHOICE_LIST *choices, const UNICHARSET* unicharset=0);  




int show_data(WERD_RES *word);  

int show_data(PAGE_RES_IT& pgi); 



 



#endif  // _TESDUMP_H_ //


