





#define  _TESDUMP_CPP_    
#include "TesDump.h"





// blobs count in a block  
int get_bbs(BLOCK*block){

C_BLOB_IT blob_it;  
blob_it.set_to_list(block->blob_list());   // iterator
// blob_it.set_to_list(block->reject_blobs());   

 
int ic=0; 
for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) ic++;     // 10 ��   =length() 
  
return ic; 
}





// blobs count in a block  
int get_bbs(BLOCK_LIST *blocks){

BLOCK_IT block_it = blocks;
BLOCK *block=block_it.data();

C_BLOB_IT blob_it;  blob_it.set_to_list(block->blob_list());   // iterator


int ic=0; 
for (blob_it.mark_cycle_pt(); !blob_it.cycled_list(); blob_it.forward()) ic++;     // 10 �� 
  
return ic; 
}





int get_size(PAGE_RES* page_res){

PAGE_RES_IT page_res_it(page_res);  // Prepare all the words.

int ic=0;  
for (page_res_it.restart_page(); page_res_it.word() != NULL;page_res_it.forward()) ic++; 


return ic;  
}






int get_size(WERD*src){

int ic=0; 

C_BLOB_IT b_it(src->cblob_list());
  
for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) ic++;   // C_BLOB* blob = b_it.data();

return ic; 
}



 

const char* get_str(GenericVector<UnicharRating> unichar_results, const UNICHARSET* unicharset) {    // =0

static char gsz[256]={0};
memset(gsz,0,256);
int ip=0;
const char *ch=0;  int id=0; 
     



for(int i=0; i<unichar_results.size(); i++){

const UnicharRating& result = unichar_results[i];


id=result.unichar_id;  

if(id<=-1 ) ch=""; 
else if(unicharset) ch= unicharset->unichars[id].representation;   
else  ch="";  

ip+=sprintf(gsz+ip,"%s[%d]\t", ch, id); 

}    //  for   


return gsz; 
}
 




const char* get_str(ADAPT_RESULTS *Results, const UNICHARSET* unicharset) {    // =0

static char gsz[256]={0};
memset(gsz,0,256);
int ip=0;
const char *ch=0;  int id=0; 
     



for(int i=0; i<Results->match.size(); i++){

const UnicharRating& result = Results->match[i];


id=result.unichar_id;  

if(id<=-1 ) ch=""; 
else if(unicharset) ch= unicharset->unichars[id].representation;   
else  ch="";  

ip+=sprintf(gsz+ip,"%s[%d]\t", ch, id); 

}    //  for   


return gsz; 
}
 



const char* get_str(BLOB_CHOICE_LIST *choices, const UNICHARSET* unicharset) {    // =0

static char gsz[256]={0};
memset(gsz,0,256);
int ip=0;
const char *ch=0;  int id=0; 
     

BLOB_CHOICE_IT it(choices);

for (it.mark_cycle_pt (); !it.cycled_list (); it.forward ()){

 

BLOB_CHOICE*ci= it.data(); 
 
// fprintf(fp,"\tr%.2f c%.2f x[%g,%g]: %d %s",    ci->rating_, ci->certainty_,  ci->min_xheight_, ci->max_xheight_, ci->unichar_id_,( word->uch_set == NULL) ? "" :  word->uch_set->debug_str(ci->unichar_id_).string());

// fprintf(fp,"\t%s[%d] ",( word->uch_set == NULL) ? "" :  word->uch_set->debug_str(ci->unichar_id_).string(),  ci->unichar_id_);


id=ci->unichar_id_; 
if(id<=-1 ) ch=""; 
else if(unicharset) ch= unicharset->unichars[id].representation;   
else  ch="";  

ip+=sprintf(gsz+ip,"%s[%d]\t", ch, id); 

}  
// for it  

return gsz; 
}
 


 

int show_data(WERD_RES *word){

FILE *fp=fopen("show_data.log", "wb");
fprintf(fp, "\r\nblob/%d     \tchoice\t\r\n", word->chopped_word->blobs.size() ); 

for (int b = 0; b < word->chopped_word->blobs.size(); ++b) {

BLOB_CHOICE_LIST*choices= word->ratings->get(b, b);

fprintf(fp, " %d(%d)\t    ",  b, choices->length()); 
fprintf(fp, "%s\t    \r\n",  get_str(choices,word->uch_set) ); 

}  // for 

fprintf(fp, "\r\n"); 
fclose(fp);
ShellExecute(0, "open", "show_data.log", 0, 0, SW_SHOW);


return word->chopped_word->blobs.size();
}



int show_data(PAGE_RES_IT& pgi){


// qTrace("get_size( pgi.word_res->word ) =%d",get_size( pgi.word_res->word )  );

FILE *fp=fopen("show_data_pgi.log", "wb");
fprintf(fp, "\r\nblob/%d     \toutlines\t\r\n", get_size( pgi.word_res->word )  ); 

C_BLOB_IT b_it(pgi.word_res->word->cblob_list());
  
int b=0; 
for (b_it.mark_cycle_pt(); !b_it.cycled_list(); b_it.forward()) {

fprintf(fp, " %d\t    %d\r\n",  b, b_it.data()->outlines.length()); 

b++; 
}  //  for 


fprintf(fp, "\r\n"); 
fclose(fp);
ShellExecute(0, "open", "show_data_pgi.log", 0, 0, SW_SHOW);


return b;
}

  