



// ������/ϵͳ:  ���� (/SUBSYSTEM:CONSOLE) --> ���� (/SUBSYSTEM:WINDOWS), ��Ҫ�ṩ WinMain ���� 







#include "baseapi.h"


#include "tesseractclass.h"

#include "tesseract/ccutil/genericvector.h"


#include "tesseract/textord/makerow.h"
#include "tesseract/textord/baselinedetect.h"
#include "tesseract/textord/wordseg.h"


#include <shellapi.h>

using namespace tesseract;     // ������ WordData �ȵ�  


int main32(char*image, char*outputbase=0, char* lang = "eng") {  // û�о����ض���Ĭ��ֵ!

char* datapath = new char[256]; *datapath = 0;         // �����ļ�λ��   ��Ҫ�� + /tessdata/ + [eng].traineddata
//strcpy(datapath, "C:/Worksite/����ʶ��/tesseract/tessdata3.02");   \
strcpy(datapath, "d:/Tbyang20/����ʶ��/Worksite/tessdata3.02");   //  ���� "../"

GetCurrentDirectory(256,datapath);  strcat(datapath,"/Worksite");  // ��ǰ·��һ���� .sln ����λ��, ������׺'\\'.  �����ܱ��������. 


static tesseract::TessBaseAPI api;      // static -- Avoid memory leak caused by auto variable when exit() is called.
api.tesseract_ = new tesseract::Tesseract;

api.tesseract_->m_init_tesseract_lang_data(datapath, lang);   //, &vars_vec, &vars_values);  

api.tesseract_->m_InitAdaptiveClassifier(true);


api.thresholder_ = new tesseract::ImageThresholder;

Pix *pix = pixRead(image);

api.thresholder_->SetImage(pix);
api.Threshold(&api.tesseract_->pix_binary_);   



api.block_list_ = new BLOCK_LIST;    


#if SEGMENT_PAGE|1

BLOCK_IT block_it(api.block_list_);
BLOCK* block = new BLOCK("", TRUE, 0, 0, 0, 0, api.tesseract_->pix_binary_->w, api.tesseract_->pix_binary_->h);
block->set_right_to_left(api.tesseract_->right_to_left_);  block_it.add_to_end(block);


TO_BLOCK_LIST to_blocks;



 


//\\ TextordPage


if (to_blocks.empty()) api.tesseract_->textord_.find_components(api.tesseract_->pix_binary_, api.block_list_, &to_blocks);  // AutoPageSeg was not used, so we need to find_components first.
    

 

TO_BLOCK_IT to_block_it(&to_blocks);
TO_BLOCK* to_block = to_block_it.data();  // 1��  
  

float gradient= make_rows(api.tesseract_->textord_.page_tr_, &to_blocks);  // Make the rows in the block. // Do it the old fashioned way.
 
BaselineDetect baseline_detector(0, api.tesseract_->reskew_, &to_blocks);


baseline_detector.ComputeBaselineSplinesAndXheights( api.tesseract_->textord_.page_tr_, true, textord_heavy_nr, textord_show_final_rows, &api.tesseract_->textord_);


make_words(&api.tesseract_->textord_, api.tesseract_->textord_.page_tr_,   0*gradient, api.block_list_, &to_blocks);  // Now make the words in the lines.    // SINGLE_LINE uses the old word maker on the single line.
 



#endif  // SEGMENT_PAGE






api.page_res_ = new PAGE_RES(false, api.block_list_, 0);  // 1 �� // qTrace("page_res_: %d", get_size(page_res_) ); // PAGE_RES_IT page_res_it(page_res_);


#if API_RECOGNIZE|1

GenericVector<WordData> words;   

int ic=0;
PAGE_RES_IT page_res_it(api.page_res_);    // Prepare all the words.

for (page_res_it.restart_page(); page_res_it.word_res != NULL;page_res_it.forward()) {
ic++;    //  qTrace("get_size( page_res_it.word_res->word)=%d", get_size( page_res_it.word_res->word));    // 10 �� 
words.push_back(WordData(page_res_it));   
// show_data( page_res_it ); 
}   // qTrace("ic=%d", ic);  // 1 ��    


#endif  // API_RECOGNIZE




// api.m_Recognize(words); 
// void Tesseract::SetupWordPassN(int pass_n, WordData* word) 
// tesseract_->SetupWordPassN(2, &words[w])

#if SETUPWORDS_PASSN |1 

 
WordData& word=  words[0];


if (!word.word->done) {
    

int s=0;  

Tesseract* lang_t = api.tesseract_;  //  s < api.tesseract_->sub_langs_.size() ? api.tesseract_->sub_langs_[s] : api.tesseract_;      // The sub_langs_.size() entry is for the master language.
 

WERD_RES* word_res = new WERD_RES;


word_res->word = word.word->word;
word_res->CopySimpleFields(*word.word);

word.lang_words.push_back(word_res);

word_res->chopped_word = TWERD::PolygonalCopy(lang_t->poly_allow_detailed_fx, word_res->word);

// tesseract::OcrEngineMode norm_mode_hint = tesseract::OEM_TESSERACT_ONLY;  // static_cast<tesseract::OcrEngineMode>( (int)lang_t->tessedit_ocr_engine_mode);
// float word_xheight = lang_t->textord_use_cjk_fp_model && word.row != NULL && word.row->body_size() > 0.0f ? word.row->body_size() : word_res->x_height;

word_res->chopped_word->BLNormalize( word.block, word.row, api.tesseract_->BestPix(), word_res->word->flag(W_INVERSE),  word_res->x_height, 
word_res->baseline_shift, lang_t->classify_bln_numeric_mode,  OEM_TESSERACT_ONLY, 0, &word_res->denorm);   // ȱ�ٴ˺�����������ʶ����.

word_res->uch_set=&lang_t->unicharset; 

// qTrace("word_res->chopped_word->blobs.size()=%d", word_res->chopped_word->blobs.size());



}  // if  



// qTrace("pass_n=%d,  ->blobs.size=%d", pass_n,  word[0].lang_words[0]->chopped_word->blobs.size());

#endif      //  SETUPWORDS_PASSN 




WERD_RES* wordr = words[0].lang_words[0];    //  qTrace("word->ratings->dimension()=%d", word->ratings->dimension());


#if CHOP_WORD|1

int num_blobs = wordr->chopped_word->blobs.size();   

FILE *fp=fopen("dump_it.log", "wb");   

fprintf(fp, "\r\nblob/%d     \tunichar_results\t\r\n", num_blobs); 
//fprintf(fp, "\r\nblob/%d     \tsample\t\r\n", num_blobs); 



for (int b = 0; b < num_blobs; ++b) {



#if ADAPTIVE_CLASSIFIER|1

INT_FX_RESULT_STRUCT fx_info; GenericVector<INT_FEATURE_STRUCT> bl_features;
TrainingSample* sample = BlobToTrainingSample(*wordr->chopped_word->blobs[b], api.tesseract_->classify_nonlinear_norm, &fx_info, &bl_features);
 

//fprintf(fp, "%d[%d]\t    ",  b,  sample->num_features());    
// fprintf(fp, "%s\t    \r\n",  get_str(unichar_results,wordr->uch_set) ); 


#if CHARNORM_CLASSIFIER |1
 
GenericVector<UnicharRating> unichar_results; 


#if SAMPLE_CHAR|1

Classify* pcf=((TessClassifier*)api.tesseract_->static_classifier_)->classify_;  

ADAPT_RESULTS* adapt_results = new ADAPT_RESULTS();   adapt_results->Initialize();
  

pcf->PruneClasses(pcf->PreTrainedTemplates, sample->num_features(), -1, sample->features(),  0,     \
               pcf->shape_table_ != NULL ? &pcf->shapetable_cutoffs_[0] : pcf->CharNormCutoffs,    \
               &adapt_results->CPResults);


// qTrace("adapt_results->CPResults=%d", adapt_results->CPResults);   // �� 
 
    
#if MASTER_MATCHER|1
  
unichar_results.clear();
UnicharRating int_result;

for (int c = 0; c < adapt_results->CPResults.size(); c++) {

CLASS_ID class_id = int_result.unichar_id =adapt_results->CPResults[c].Class;
int_result.feature_misses = 0;
    

#if INT_MATCH|1

BIT_VECTOR protos =   pcf->AllProtosOn, configs =  pcf->AllConfigsOn;
                                         
ScratchEvidence *tables = new ScratchEvidence();

tables->Clear( ClassForClassId(pcf->PreTrainedTemplates, class_id) );
  
for (int Feature = 0; Feature < sample->num_features(); Feature++) 
  pcf->im_.UpdateTablesForFeature(ClassForClassId(pcf->PreTrainedTemplates, class_id), protos, configs, Feature, &sample->features()[Feature], tables, pcf->matcher_debug_flags);
 
tables->NormalizeSums(ClassForClassId(pcf->PreTrainedTemplates, class_id), sample->num_features(), sample->num_features());

pcf->im_.FindBestMatch(ClassForClassId(pcf->PreTrainedTemplates, class_id), *tables, &int_result);
 
delete tables;

#endif  //  INT_MATCH



unichar_results.push_back(int_result);  // unichar_results.push_back(adapt_results->match[c]);

}






// Convert master matcher results to output format.
// for (int i = 0; i < adapt_results->match.size(); i++)   unichar_results.push_back(adapt_results->match[i]);

  
#endif     //  MASTER_MATCHER

unichar_results.sort(&UnicharRating::SortDescendingRating);
 

delete adapt_results;

#endif   // SAMPLE_CHAR





fprintf(fp, "%d[%d]\t    ",  b,  unichar_results.size());   \
fprintf(fp, "%s\t    \r\n",  get_str(unichar_results,wordr->uch_set) ); 

#endif  // CHARNORM_CLASSIFIER

 
#endif   // ADAPTIVE_CLASSIFIER  

}  // for b 


fprintf(fp, "\r\n");  fclose(fp);
ShellExecute(0, "open", "dump_it.log", 0, 0, SW_SHOW);


// show_data(wordr); 

#endif  // CHOP_WORD



return num_blobs;
}












